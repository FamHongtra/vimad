#!/bin/bash

fname=eiei.txt

filepath=/root/eiei.txt

clear

